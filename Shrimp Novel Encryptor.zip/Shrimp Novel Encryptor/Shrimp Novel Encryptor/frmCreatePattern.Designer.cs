﻿namespace Shrimp_Novel_Encryptor
{
    partial class frmCreatePattern
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.spltMaster = new System.Windows.Forms.SplitContainer();
            this.txtZ = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtY = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtM = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtO = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtS = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtR = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtX = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtW = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtV = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtQ = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtL = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtU = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtP = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtK = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtJ = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtI = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtH = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtG = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtF = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtE = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.savePattern = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.spltMaster)).BeginInit();
            this.spltMaster.Panel1.SuspendLayout();
            this.spltMaster.Panel2.SuspendLayout();
            this.spltMaster.SuspendLayout();
            this.SuspendLayout();
            // 
            // spltMaster
            // 
            this.spltMaster.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltMaster.Location = new System.Drawing.Point(0, 0);
            this.spltMaster.Name = "spltMaster";
            this.spltMaster.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltMaster.Panel1
            // 
            this.spltMaster.Panel1.Controls.Add(this.txtZ);
            this.spltMaster.Panel1.Controls.Add(this.label26);
            this.spltMaster.Panel1.Controls.Add(this.txtY);
            this.spltMaster.Panel1.Controls.Add(this.label25);
            this.spltMaster.Panel1.Controls.Add(this.txtM);
            this.spltMaster.Panel1.Controls.Add(this.label24);
            this.spltMaster.Panel1.Controls.Add(this.txtN);
            this.spltMaster.Panel1.Controls.Add(this.label23);
            this.spltMaster.Panel1.Controls.Add(this.txtO);
            this.spltMaster.Panel1.Controls.Add(this.label22);
            this.spltMaster.Panel1.Controls.Add(this.txtT);
            this.spltMaster.Panel1.Controls.Add(this.label21);
            this.spltMaster.Panel1.Controls.Add(this.txtS);
            this.spltMaster.Panel1.Controls.Add(this.label20);
            this.spltMaster.Panel1.Controls.Add(this.txtR);
            this.spltMaster.Panel1.Controls.Add(this.label19);
            this.spltMaster.Panel1.Controls.Add(this.txtX);
            this.spltMaster.Panel1.Controls.Add(this.label18);
            this.spltMaster.Panel1.Controls.Add(this.txtW);
            this.spltMaster.Panel1.Controls.Add(this.label17);
            this.spltMaster.Panel1.Controls.Add(this.txtV);
            this.spltMaster.Panel1.Controls.Add(this.label16);
            this.spltMaster.Panel1.Controls.Add(this.txtQ);
            this.spltMaster.Panel1.Controls.Add(this.label15);
            this.spltMaster.Panel1.Controls.Add(this.txtL);
            this.spltMaster.Panel1.Controls.Add(this.label14);
            this.spltMaster.Panel1.Controls.Add(this.txtU);
            this.spltMaster.Panel1.Controls.Add(this.label13);
            this.spltMaster.Panel1.Controls.Add(this.txtP);
            this.spltMaster.Panel1.Controls.Add(this.label12);
            this.spltMaster.Panel1.Controls.Add(this.txtK);
            this.spltMaster.Panel1.Controls.Add(this.label11);
            this.spltMaster.Panel1.Controls.Add(this.txtJ);
            this.spltMaster.Panel1.Controls.Add(this.label10);
            this.spltMaster.Panel1.Controls.Add(this.txtI);
            this.spltMaster.Panel1.Controls.Add(this.label9);
            this.spltMaster.Panel1.Controls.Add(this.txtH);
            this.spltMaster.Panel1.Controls.Add(this.label8);
            this.spltMaster.Panel1.Controls.Add(this.txtG);
            this.spltMaster.Panel1.Controls.Add(this.label7);
            this.spltMaster.Panel1.Controls.Add(this.txtF);
            this.spltMaster.Panel1.Controls.Add(this.label6);
            this.spltMaster.Panel1.Controls.Add(this.txtE);
            this.spltMaster.Panel1.Controls.Add(this.label5);
            this.spltMaster.Panel1.Controls.Add(this.txtD);
            this.spltMaster.Panel1.Controls.Add(this.label4);
            this.spltMaster.Panel1.Controls.Add(this.txtC);
            this.spltMaster.Panel1.Controls.Add(this.label3);
            this.spltMaster.Panel1.Controls.Add(this.txtB);
            this.spltMaster.Panel1.Controls.Add(this.label2);
            this.spltMaster.Panel1.Controls.Add(this.txtA);
            this.spltMaster.Panel1.Controls.Add(this.label1);
            this.spltMaster.Panel1.Controls.Add(this.lblTitle);
            this.spltMaster.Panel1.Controls.Add(this.btnRefresh);
            // 
            // spltMaster.Panel2
            // 
            this.spltMaster.Panel2.Controls.Add(this.btnCancel);
            this.spltMaster.Panel2.Controls.Add(this.btnSave);
            this.spltMaster.Size = new System.Drawing.Size(284, 261);
            this.spltMaster.SplitterDistance = 232;
            this.spltMaster.TabIndex = 0;
            // 
            // txtZ
            // 
            this.txtZ.Location = new System.Drawing.Point(250, 173);
            this.txtZ.Name = "txtZ";
            this.txtZ.Size = new System.Drawing.Size(20, 20);
            this.txtZ.TabIndex = 53;
            this.txtZ.Text = "z";
            this.txtZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtZ.Click += new System.EventHandler(this.txtZ_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(231, 176);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(12, 13);
            this.label26.TabIndex = 52;
            this.label26.Text = "z";
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(250, 146);
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(20, 20);
            this.txtY.TabIndex = 51;
            this.txtY.Text = "y";
            this.txtY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtY.Click += new System.EventHandler(this.txtY_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(231, 149);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(12, 13);
            this.label25.TabIndex = 50;
            this.label25.Text = "y";
            // 
            // txtM
            // 
            this.txtM.Location = new System.Drawing.Point(141, 94);
            this.txtM.Name = "txtM";
            this.txtM.Size = new System.Drawing.Size(20, 20);
            this.txtM.TabIndex = 49;
            this.txtM.Text = "m";
            this.txtM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtM.Click += new System.EventHandler(this.txtM_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(122, 97);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 13);
            this.label24.TabIndex = 48;
            this.label24.Text = "m";
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(141, 120);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(20, 20);
            this.txtN.TabIndex = 47;
            this.txtN.Text = "n";
            this.txtN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtN.Click += new System.EventHandler(this.txtN_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(122, 123);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 13);
            this.label23.TabIndex = 46;
            this.label23.Text = "n";
            // 
            // txtO
            // 
            this.txtO.Location = new System.Drawing.Point(141, 146);
            this.txtO.Name = "txtO";
            this.txtO.Size = new System.Drawing.Size(20, 20);
            this.txtO.TabIndex = 45;
            this.txtO.Text = "o";
            this.txtO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtO.Click += new System.EventHandler(this.txtO_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(122, 149);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 13);
            this.label22.TabIndex = 44;
            this.label22.Text = "o";
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(196, 146);
            this.txtT.Name = "txtT";
            this.txtT.Size = new System.Drawing.Size(20, 20);
            this.txtT.TabIndex = 43;
            this.txtT.Text = "t";
            this.txtT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtT.Click += new System.EventHandler(this.txtT_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(177, 149);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(10, 13);
            this.label21.TabIndex = 42;
            this.label21.Text = "t";
            // 
            // txtS
            // 
            this.txtS.Location = new System.Drawing.Point(196, 120);
            this.txtS.Name = "txtS";
            this.txtS.Size = new System.Drawing.Size(20, 20);
            this.txtS.TabIndex = 41;
            this.txtS.Text = "s";
            this.txtS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtS.Click += new System.EventHandler(this.txtS_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(177, 123);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(12, 13);
            this.label20.TabIndex = 40;
            this.label20.Text = "s";
            // 
            // txtR
            // 
            this.txtR.Location = new System.Drawing.Point(196, 94);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(20, 20);
            this.txtR.TabIndex = 39;
            this.txtR.Text = "r";
            this.txtR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtR.Click += new System.EventHandler(this.txtR_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(177, 97);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(10, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "r";
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(250, 120);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(20, 20);
            this.txtX.TabIndex = 37;
            this.txtX.Text = "x";
            this.txtX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtX.Click += new System.EventHandler(this.txtX_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(231, 123);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(12, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "x";
            // 
            // txtW
            // 
            this.txtW.Location = new System.Drawing.Point(250, 94);
            this.txtW.Name = "txtW";
            this.txtW.Size = new System.Drawing.Size(20, 20);
            this.txtW.TabIndex = 35;
            this.txtW.Text = "w";
            this.txtW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtW.Click += new System.EventHandler(this.txtW_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(231, 97);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 13);
            this.label17.TabIndex = 34;
            this.label17.Text = "w";
            // 
            // txtV
            // 
            this.txtV.Location = new System.Drawing.Point(250, 66);
            this.txtV.Name = "txtV";
            this.txtV.Size = new System.Drawing.Size(20, 20);
            this.txtV.TabIndex = 33;
            this.txtV.Text = "v";
            this.txtV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtV.Click += new System.EventHandler(this.txtV_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(231, 69);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "v";
            // 
            // txtQ
            // 
            this.txtQ.Location = new System.Drawing.Point(196, 66);
            this.txtQ.Name = "txtQ";
            this.txtQ.Size = new System.Drawing.Size(20, 20);
            this.txtQ.TabIndex = 31;
            this.txtQ.Text = "q";
            this.txtQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQ.Click += new System.EventHandler(this.txtQ_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(177, 69);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "q";
            // 
            // txtL
            // 
            this.txtL.Location = new System.Drawing.Point(141, 66);
            this.txtL.Name = "txtL";
            this.txtL.Size = new System.Drawing.Size(20, 20);
            this.txtL.TabIndex = 29;
            this.txtL.Text = "l";
            this.txtL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtL.Click += new System.EventHandler(this.txtL_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(122, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(9, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "l";
            // 
            // txtU
            // 
            this.txtU.Location = new System.Drawing.Point(250, 39);
            this.txtU.Name = "txtU";
            this.txtU.Size = new System.Drawing.Size(20, 20);
            this.txtU.TabIndex = 27;
            this.txtU.Text = "u";
            this.txtU.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtU.Click += new System.EventHandler(this.txtU_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(231, 42);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "u";
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(196, 39);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(20, 20);
            this.txtP.TabIndex = 25;
            this.txtP.Text = "p";
            this.txtP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtP.Click += new System.EventHandler(this.txtP_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(177, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "p";
            // 
            // txtK
            // 
            this.txtK.Location = new System.Drawing.Point(141, 39);
            this.txtK.Name = "txtK";
            this.txtK.Size = new System.Drawing.Size(20, 20);
            this.txtK.TabIndex = 23;
            this.txtK.Text = "k";
            this.txtK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtK.Click += new System.EventHandler(this.txtK_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(122, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "k";
            // 
            // txtJ
            // 
            this.txtJ.Location = new System.Drawing.Point(85, 146);
            this.txtJ.Name = "txtJ";
            this.txtJ.Size = new System.Drawing.Size(20, 20);
            this.txtJ.TabIndex = 21;
            this.txtJ.Text = "j";
            this.txtJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtJ.Click += new System.EventHandler(this.txtJ_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(66, 149);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(9, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "j";
            // 
            // txtI
            // 
            this.txtI.Location = new System.Drawing.Point(85, 120);
            this.txtI.Name = "txtI";
            this.txtI.Size = new System.Drawing.Size(20, 20);
            this.txtI.TabIndex = 19;
            this.txtI.Text = "i";
            this.txtI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtI.Click += new System.EventHandler(this.txtI_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(66, 123);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(9, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "i";
            // 
            // txtH
            // 
            this.txtH.Location = new System.Drawing.Point(85, 94);
            this.txtH.Name = "txtH";
            this.txtH.Size = new System.Drawing.Size(20, 20);
            this.txtH.TabIndex = 17;
            this.txtH.Text = "h";
            this.txtH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtH.Click += new System.EventHandler(this.txtH_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(66, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "h";
            // 
            // txtG
            // 
            this.txtG.Location = new System.Drawing.Point(85, 66);
            this.txtG.Name = "txtG";
            this.txtG.Size = new System.Drawing.Size(20, 20);
            this.txtG.TabIndex = 15;
            this.txtG.Text = "g";
            this.txtG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtG.Click += new System.EventHandler(this.txtG_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "g";
            // 
            // txtF
            // 
            this.txtF.Location = new System.Drawing.Point(85, 39);
            this.txtF.Name = "txtF";
            this.txtF.Size = new System.Drawing.Size(20, 20);
            this.txtF.TabIndex = 13;
            this.txtF.Text = "f";
            this.txtF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtF.Click += new System.EventHandler(this.txtF_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(10, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "f";
            // 
            // txtE
            // 
            this.txtE.Location = new System.Drawing.Point(31, 146);
            this.txtE.Name = "txtE";
            this.txtE.Size = new System.Drawing.Size(20, 20);
            this.txtE.TabIndex = 11;
            this.txtE.Text = "e";
            this.txtE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtE.Click += new System.EventHandler(this.txtE_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "e";
            // 
            // txtD
            // 
            this.txtD.Location = new System.Drawing.Point(31, 120);
            this.txtD.Name = "txtD";
            this.txtD.Size = new System.Drawing.Size(20, 20);
            this.txtD.TabIndex = 9;
            this.txtD.Text = "d";
            this.txtD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtD.Click += new System.EventHandler(this.txtD_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "d";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(31, 94);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(20, 20);
            this.txtC.TabIndex = 7;
            this.txtC.Text = "c";
            this.txtC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtC.Click += new System.EventHandler(this.txtC_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "c";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(31, 66);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(20, 20);
            this.txtB.TabIndex = 5;
            this.txtB.Text = "b";
            this.txtB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtB.Click += new System.EventHandler(this.txtB_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "b";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(31, 39);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(20, 20);
            this.txtA.TabIndex = 3;
            this.txtA.Text = "a";
            this.txtA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtA.Click += new System.EventHandler(this.txtA_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "a";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(260, 13);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "**Replace the following letters to create new pattern**";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(206, 206);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(206, -1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(125, -1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // savePattern
            // 
            this.savePattern.Filter = "Text File|*.dat";
            this.savePattern.Title = "Choose where to save the pattern";
            // 
            // frmCreatePattern
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.spltMaster);
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "frmCreatePattern";
            this.Text = "Create New Pattern";
            this.spltMaster.Panel1.ResumeLayout(false);
            this.spltMaster.Panel1.PerformLayout();
            this.spltMaster.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltMaster)).EndInit();
            this.spltMaster.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer spltMaster;
        private System.Windows.Forms.TextBox txtZ;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtY;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtM;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtO;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtS;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtW;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtV;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtQ;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtL;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtU;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtK;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtJ;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtI;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtH;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtF;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SaveFileDialog savePattern;
    }
}